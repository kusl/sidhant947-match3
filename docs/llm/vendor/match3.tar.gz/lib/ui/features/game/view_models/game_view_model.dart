import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:match3/data/repositories/progress_repository.dart';
import 'package:match3/domain/models/game_state_model.dart';
import 'package:match3/domain/models/level_generator.dart';
import 'package:match3/domain/models/level_goal.dart';
import 'package:match3/domain/models/tile_model.dart';
import 'package:match3/domain/services/best_move_finder.dart';

class GameViewModel extends ChangeNotifier {
  final ProgressRepository progressRepository;
  final Random _random = Random();

  late LevelConfig _levelConfig;
  bool _isZenMode = false;
  bool _isTimeAttack = false;
  bool _isTwistMode = false;
  bool get isTwistMode => _isTwistMode;
  late LevelGoal _currentGoal;
  Timer? _hintTimer;
  Timer? _timeAttackTimer;
  Set<String> _lastSwappedTileIds = const {};

  GameStateModel _state = const GameStateModel(
    tiles: [],
    score: 0,
    highScore: 0,
    movesLeft: 25,
    targetScore: 1000,
    isGameOver: false,
    rows: 8,
    cols: 8,
    comboCount: 0,
    levelNumber: 1,
  );

  GameStateModel get state => _state;
  bool _isProcessing = false;
  bool get isProcessing => _isProcessing;

  GameViewModel({
    required this.progressRepository,
  });

  @override
  void dispose() {
    _hintTimer?.cancel();
    _timeAttackTimer?.cancel();
    super.dispose();
  }

  Future<void> initGame({int level = 1, bool isZenMode = false, bool isTimeAttack = false, bool isTwistMode = false}) async {
    _hintTimer?.cancel();
    _timeAttackTimer?.cancel();
    _isZenMode = isZenMode;
    _isTimeAttack = isTimeAttack;
    _isTwistMode = isTwistMode;

    final userProgress = await progressRepository.getProgress();
    _levelConfig = LevelGenerator.generate(
      level,
      isZenMode: isZenMode || isTimeAttack || isTwistMode,
      rows: 8,
      cols: 8,
      activeFruits: userProgress.activeEmojiSet,
      disableTimedChallenges: userProgress.disableTimedChallenges,
    );
    _currentGoal = isTimeAttack
        ? const LevelGoal(
            type: LevelGoalType.score,
            title: 'TIME ATTACK',
            description: 'Score as much as you can before time runs out!',
            targetValue: 999999,
          )
        : (isTwistMode
            ? const LevelGoal(
                type: LevelGoalType.score,
                title: 'TWIST MODE',
                description: 'Rotate clockwise to match and relax',
                targetValue: 999999,
              )
            : _levelConfig.goal);
    final effectiveHighScore = userProgress.levelStars[level.toString()] != null
        ? userProgress.levelStars[level.toString()]! * 1000
        : 0;

    final initialTiles = _generateInitialBoard(8, 8, _levelConfig.fruitVarietyCount, _levelConfig.frozenTiles, _levelConfig.crateTiles);

    _state = GameStateModel(
      tiles: initialTiles,
      score: 0,
      highScore: effectiveHighScore,
      movesLeft: (isTimeAttack || isTwistMode || isZenMode || _levelConfig.isTimed) ? 999 : _levelConfig.moves,
      targetScore: _levelConfig.targetScore,
      goal: _currentGoal,
      isGameOver: false,
      rows: 8,
      cols: 8,
      comboCount: 0,
      levelNumber: level,
      star1Score: _levelConfig.star1Score,
      star2Score: _levelConfig.star2Score,
      star3Score: _levelConfig.star3Score,
      starsEarned: 0,
      jellyTiles: _levelConfig.jellyTiles,
      hintTileIds: const {},
      isShuffling: false,
      isTimeAttack: isTimeAttack,
      isTwistMode: isTwistMode,
      timeLeft: isTimeAttack ? 60 : (_levelConfig.timeLimit ?? 0),
      levelConfig: _levelConfig,
    );
    _isProcessing = false;
    notifyListeners();
    _resetHintTimer();

    if (isTimeAttack || _levelConfig.isTimed) {
      _startTimeAttackTimer();
    }
  }

  void _startTimeAttackTimer() {
    _timeAttackTimer?.cancel();
    _timeAttackTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (_state.isGameOver) {
        timer.cancel();
        return;
      }
      final newTime = _state.timeLeft - 1;
      if (newTime <= 0) {
        timer.cancel();
        final isWin = !_isTimeAttack && _currentGoal.isCompleted;
        final stars = isWin ? calculateStars(_state.score) : (_isTimeAttack ? calculateStars(_state.score) : 0);
        _state = _state.copyWith(
          timeLeft: 0,
          isGameOver: true,
          starsEarned: stars,
        );
        if (isWin) {
          progressRepository.completeLevel(
            _state.levelNumber,
            stars,
          );
        }
        notifyListeners();
      } else {
        _state = _state.copyWith(timeLeft: newTime);
        notifyListeners();
      }
    });
  }

  int calculateStars(int score) {
    if (score >= _levelConfig.star3Score) return 3;
    if (score >= _levelConfig.star2Score) return 2;
    if (score >= _levelConfig.star1Score) return 1;
    return 1;
  }

  List<String> _getAvailableFruits(int count) {
    final activeSet = progressRepository.cachedProgress.activeEmojiSet;
    final clampedCount = count.clamp(4, activeSet.length);
    return activeSet.sublist(0, clampedCount);
  }

  List<TileModel> _generateInitialBoard(int rows, int cols, int fruitCount, [Set<String> frozen = const {}, Set<String> crates = const {}]) {
    final availableFruits = _getAvailableFruits(fruitCount);
    final tiles = <TileModel>[];
    for (int r = 0; r < rows; r++) {
      for (int c = 0; c < cols; c++) {
        final key = '${r}_$c';
        if (crates.contains(key)) {
          tiles.add(TileModel(
            id: '${DateTime.now().microsecondsSinceEpoch}_${r}_${c}_${_random.nextInt(1000)}',
            row: r,
            col: c,
            emoji: progressRepository.cachedProgress.crateEmoji,
            type: TileType.crate,
            crateHealth: 2,
          ));
          continue;
        }

        final allowedFruits = List<String>.from(availableFruits);
        if (c >= 2) {
          final left1 = tiles.firstWhere((t) => t.row == r && t.col == c - 1);
          final left2 = tiles.firstWhere((t) => t.row == r && t.col == c - 2);
          if (left1.emoji == left2.emoji) {
            allowedFruits.remove(left1.emoji);
          }
        }
        if (r >= 2) {
          final up1 = tiles.firstWhere((t) => t.row == r - 1 && t.col == c);
          final up2 = tiles.firstWhere((t) => t.row == r - 2 && t.col == c);
          if (up1.emoji == up2.emoji) {
            allowedFruits.remove(up1.emoji);
          }
        }
        final emoji = allowedFruits[_random.nextInt(allowedFruits.length)];
        tiles.add(TileModel(
          id: '${DateTime.now().microsecondsSinceEpoch}_${r}_${c}_${_random.nextInt(1000)}',
          row: r,
          col: c,
          emoji: emoji,
          isFrozen: frozen.contains(key),
        ));
      }
    }
    return tiles;
  }

  void _updateGoalProgress({
    int scoreAdded = 0,
    List<TileModel> clearedTiles = const [],
    int specialsCreatedCount = 0,
    bool isCombo = false,
    int clearedJellyCount = 0,
  }) {
    int currentVal = _currentGoal.currentValue;

    switch (_currentGoal.type) {
      case LevelGoalType.score:
        currentVal = _state.score + scoreAdded;
        break;
      case LevelGoalType.targetFruit:
        final matching = clearedTiles.where((t) => t.emoji == _currentGoal.targetFruitEmoji).length;
        currentVal += matching;
        break;
      case LevelGoalType.createSpecials:
        currentVal += specialsCreatedCount;
        break;
      case LevelGoalType.comboMaster:
        if (isCombo) {
          currentVal += 1;
        }
        break;
      case LevelGoalType.clearJelly:
        currentVal += clearedJellyCount;
        break;
    }

    _currentGoal = _currentGoal.copyWith(currentValue: currentVal);
  }

  void _resetHintTimer() {
    _hintTimer?.cancel();
    if (_state.isGameOver || _isProcessing) return;

    _hintTimer = Timer(const Duration(seconds: 5), () async {
      if (_isProcessing || _state.isGameOver) return;
      final progress = await progressRepository.getProgress();
      if (!progress.hintsEnabled) return;

      final move = findBestMove();
      if (move != null) {
        _state = _state.copyWith(hintTileIds: move.map((t) => t.id).toSet());
        notifyListeners();
      }
    });
  }

  List<TileModel>? findBestMove() {
    final finder = BestMoveFinder(
      rows: _state.rows,
      cols: _state.cols,
      goal: _state.goal,
      jellyTiles: _state.jellyTiles,
      colorBombEmoji: progressRepository.cachedProgress.colorBombEmoji,
    );
    if (_isTwistMode) {
      return finder.findBestTwist(_state.tiles) ?? findPossibleTwistMove(_state.tiles, _state.rows, _state.cols);
    }
    return finder.findBestSwap(_state.tiles) ?? findPossibleMove(_state.tiles, _state.rows, _state.cols);
  }

  void clearHints() {
    if (_state.hintTileIds.isNotEmpty) {
      _state = _state.copyWith(hintTileIds: const {});
      notifyListeners();
    }
    _resetHintTimer();
  }

  List<TileModel>? findPossibleTwistMove(List<TileModel> tiles, int rows, int cols) {
    for (int r = 0; r < rows - 1; r++) {
      for (int c = 0; c < cols - 1; c++) {
        final tTL = _tileAt(tiles, r, c);
        final tTR = _tileAt(tiles, r, c + 1);
        final tBR = _tileAt(tiles, r + 1, c + 1);
        final tBL = _tileAt(tiles, r + 1, c);

        if (tTL == null || tTR == null || tBR == null || tBL == null) continue;
        if (!tTL.canSwap || !tTR.canSwap || !tBR.canSwap || !tBL.canSwap) continue;

        var sim = tiles.map((t) {
          if (t.id == tTL.id) return t.copyWith(row: r, col: c + 1);
          if (t.id == tTR.id) return t.copyWith(row: r + 1, col: c + 1);
          if (t.id == tBR.id) return t.copyWith(row: r + 1, col: c);
          if (t.id == tBL.id) return t.copyWith(row: r, col: c);
          return t;
        }).toList();
        if (_findMatches(sim).isNotEmpty) return [tTL, tTR, tBR, tBL];

        sim = tiles.map((t) {
          if (t.id == tTL.id) return t.copyWith(row: r + 1, col: c + 1);
          if (t.id == tTR.id) return t.copyWith(row: r + 1, col: c);
          if (t.id == tBR.id) return t.copyWith(row: r, col: c);
          if (t.id == tBL.id) return t.copyWith(row: r, col: c + 1);
          return t;
        }).toList();
        if (_findMatches(sim).isNotEmpty) return [tTL, tTR, tBR, tBL];

        sim = tiles.map((t) {
          if (t.id == tTL.id) return t.copyWith(row: r + 1, col: c);
          if (t.id == tTR.id) return t.copyWith(row: r, col: c);
          if (t.id == tBR.id) return t.copyWith(row: r, col: c + 1);
          if (t.id == tBL.id) return t.copyWith(row: r + 1, col: c + 1);
          return t;
        }).toList();
        if (_findMatches(sim).isNotEmpty) return [tTL, tTR, tBR, tBL];
      }
    }
    return null;
  }

  TileModel? _tileAt(List<TileModel> tiles, int r, int c) {
    for (final t in tiles) {
      if (t.row == r && t.col == c) return t;
    }
    return null;
  }

  Future<bool> rotateClusterClockwise(int r, int c) async {
    if (_isProcessing || _state.isGameOver) return false;
    if (r < 0 || r >= _state.rows - 1 || c < 0 || c >= _state.cols - 1) return false;

    _hintTimer?.cancel();
    _isProcessing = true;
    _state = _state.copyWith(hintTileIds: const {});

    try {
      final tTL = _state.getTile(r, c);
      final tTR = _state.getTile(r, c + 1);
      final tBR = _state.getTile(r + 1, c + 1);
      final tBL = _state.getTile(r + 1, c);

      if (tTL == null || tTR == null || tBR == null || tBL == null) return false;
      if (!tTL.canSwap || !tTR.canSwap || !tBR.canSwap || !tBL.canSwap) return false;

      final rotatedTiles = _state.tiles.map((tile) {
        if (tile.id == tTL.id) {
          return tile.copyWith(row: r, col: c + 1);
        } else if (tile.id == tTR.id) {
          return tile.copyWith(row: r + 1, col: c + 1);
        } else if (tile.id == tBR.id) {
          return tile.copyWith(row: r + 1, col: c);
        } else if (tile.id == tBL.id) {
          return tile.copyWith(row: r, col: c);
        }
        return tile;
      }).toList();

      _state = _state.copyWith(tiles: rotatedTiles, comboCount: 0);
      _lastSwappedTileIds = {tTL.id, tTR.id, tBR.id, tBL.id};
      notifyListeners();

      await Future.delayed(const Duration(milliseconds: 260));

      final matches = _findMatches(rotatedTiles);
      if (matches.isNotEmpty) {
        await _processMatchesAndCascade();
      } else {
        if (progressRepository.cachedProgress.twistLimiterEnabled) {
          await Future.delayed(const Duration(milliseconds: 200));
          final revertedTiles = _state.tiles.map((tile) {
            if (tile.id == tTL.id) return tile.copyWith(row: r, col: c);
            if (tile.id == tTR.id) return tile.copyWith(row: r, col: c + 1);
            if (tile.id == tBR.id) return tile.copyWith(row: r + 1, col: c + 1);
            if (tile.id == tBL.id) return tile.copyWith(row: r + 1, col: c);
            return tile;
          }).toList();
          _state = _state.copyWith(tiles: revertedTiles);
          notifyListeners();
          return false;
        }
        await _checkAndPerformShuffleIfNeeded();
      }
      return true;
    } finally {
      _lastSwappedTileIds = const {};
      _isProcessing = false;
      _resetHintTimer();
    }
  }

  List<TileModel>? findPossibleMove(List<TileModel> tiles, int rows, int cols) {
    for (int r = 0; r < rows; r++) {
      for (int c = 0; c < cols; c++) {
        final t1 = tiles.firstWhere((t) => t.row == r && t.col == c);
        if (!t1.canSwap) continue;

        if (c + 1 < cols) {
          final t2 = tiles.firstWhere((t) => t.row == r && t.col == c + 1);
          if (t2.canSwap && _isValidMove(t1, t2, tiles, rows, cols)) {
            return [t1, t2];
          }
        }

        if (r + 1 < rows) {
          final t2 = tiles.firstWhere((t) => t.row == r + 1 && t.col == c);
          if (t2.canSwap && _isValidMove(t1, t2, tiles, rows, cols)) {
            return [t1, t2];
          }
        }
      }
    }
    return null;
  }

  bool _isValidMove(TileModel t1, TileModel t2, List<TileModel> tiles, int rows, int cols) {
    if (!t1.canSwap || !t2.canSwap) return false;
    if (t1.type == TileType.colorBomb || t2.type == TileType.colorBomb) return true;
    if (t1.type != TileType.normal && t2.type != TileType.normal) return true;

    final simulated = tiles.map((t) {
      if (t.id == t1.id) return t.copyWith(row: t2.row, col: t2.col);
      if (t.id == t2.id) return t.copyWith(row: t1.row, col: t1.col);
      return t;
    }).toList();

    final matches = _findMatches(simulated);
    return matches.isNotEmpty;
  }

  bool _isSpecialCombination(TileModel t1, TileModel t2) {
    if (t1.type == TileType.colorBomb || t2.type == TileType.colorBomb) return true;
    if (t1.type != TileType.normal && t2.type != TileType.normal) return true;
    return false;
  }

  Future<bool> swapTiles(int r1, int c1, int r2, int c2) async {
    if (_isTwistMode || _isProcessing || _state.isGameOver) return false;
    if (r1 == r2 && c1 == c2) return false;
    _hintTimer?.cancel();
    _isProcessing = true;
    _state = _state.copyWith(hintTileIds: const {});

    try {
      final tile1 = _state.getTile(r1, c1);
      final tile2 = _state.getTile(r2, c2);
      if (tile1 == null || tile2 == null) {
        return false;
      }
      if (!tile1.canSwap || !tile2.canSwap) {
        return false;
      }

      final swappedTiles = _state.tiles.map((tile) {
        if (tile.id == tile1.id) {
          return tile.copyWith(row: r2, col: c2);
        } else if (tile.id == tile2.id) {
          return tile.copyWith(row: r1, col: c1);
        }
        return tile;
      }).toList();

      _state = _state.copyWith(tiles: swappedTiles);
      notifyListeners();

      if (_isSpecialCombination(tile1, tile2)) {
        final newMoves = (_isZenMode || _isTimeAttack || _levelConfig.isTimed) ? _state.movesLeft : _state.movesLeft - 1;
        _state = _state.copyWith(movesLeft: newMoves);
        await _handleSpecialCombination(tile1.copyWith(row: r2, col: c2), tile2.copyWith(row: r1, col: c1));
        return true;
      }

      final matches = _findMatches(swappedTiles);
      if (matches.isEmpty) {
        await Future.delayed(const Duration(milliseconds: 200));
        _state = _state.copyWith(tiles: _state.tiles.map((tile) {
          if (tile.id == tile1.id) {
            return tile.copyWith(row: r1, col: c1);
          } else if (tile.id == tile2.id) {
            return tile.copyWith(row: r2, col: c2);
          }
          return tile;
        }).toList());
        notifyListeners();
        return false;
      }

      final newMoves = (_isZenMode || _isTimeAttack || _levelConfig.isTimed) ? _state.movesLeft : _state.movesLeft - 1;
      _state = _state.copyWith(movesLeft: newMoves, comboCount: 0);
      _lastSwappedTileIds = {tile1.id, tile2.id};
      notifyListeners();

      await _processMatchesAndCascade();
      return true;
    } finally {
      _lastSwappedTileIds = const {};
      _isProcessing = false;
      _resetHintTimer();
    }
  }

  Future<void> _handleSpecialCombination(TileModel t1, TileModel t2) async {
    final isT1Bomb = t1.type == TileType.colorBomb;
    final isT2Bomb = t2.type == TileType.colorBomb;
    final isT1Striped = t1.type == TileType.stripedHorizontal || t1.type == TileType.stripedVertical;
    final isT2Striped = t2.type == TileType.stripedHorizontal || t2.type == TileType.stripedVertical;
    final isT1Wrapped = t1.type == TileType.wrapped;
    final isT2Wrapped = t2.type == TileType.wrapped;

    final targetRow = t1.row;
    final targetCol = t1.col;
    final toDestroy = <TileModel>{t1, t2};

    if (isT1Bomb && isT2Bomb) {
      toDestroy.addAll(_state.tiles);
    } else if ((isT1Bomb && isT2Striped) || (isT2Bomb && isT1Striped)) {
      final other = isT1Bomb ? t2 : t1;
      final matchingColor = _state.tiles.where((t) => t.emoji == other.emoji).toList();
      toDestroy.addAll(matchingColor);
      for (final tile in matchingColor) {
        toDestroy.addAll(_state.tiles.where((t) => t.row == tile.row || t.col == tile.col));
      }
    } else if ((isT1Bomb && isT2Wrapped) || (isT2Bomb && isT1Wrapped)) {
      final other = isT1Bomb ? t2 : t1;
      final matchingColor = _state.tiles.where((t) => t.emoji == other.emoji).toList();
      toDestroy.addAll(matchingColor);
      for (final tile in matchingColor) {
        toDestroy.addAll(_state.tiles.where((t) => (t.row - tile.row).abs() <= 1 && (t.col - tile.col).abs() <= 1));
      }
    } else if (isT1Bomb || isT2Bomb) {
      final other = isT1Bomb ? t2 : t1;
      toDestroy.addAll(_state.tiles.where((t) => t.emoji == other.emoji));
    } else if (isT1Striped && isT2Striped) {
      toDestroy.addAll(_state.tiles.where((t) => t.row == targetRow || t.col == targetCol));
    } else if ((isT1Striped && isT2Wrapped) || (isT2Striped && isT1Wrapped)) {
      toDestroy.addAll(_state.tiles.where((t) => (t.row - targetRow).abs() <= 1 || (t.col - targetCol).abs() <= 1));
    } else if (isT1Wrapped && isT2Wrapped) {
      toDestroy.addAll(_state.tiles.where((t) => (t.row - targetRow).abs() <= 2 && (t.col - targetCol).abs() <= 2));
    }

    final toDestroyList = toDestroy.toList();
    final remainingJelly = Set<String>.from(_state.jellyTiles);
    int clearedJelly = 0;
    for (final t in toDestroyList) {
      final key = '${t.row}_${t.col}';
      if (remainingJelly.remove(key)) {
        clearedJelly++;
      }
    }

    final scoreAdded = toDestroyList.length * 60;
    final newScore = _state.score + scoreAdded;
    _updateGoalProgress(
      scoreAdded: scoreAdded,
      clearedTiles: toDestroyList,
      specialsCreatedCount: 0,
      isCombo: _state.comboCount > 0,
      clearedJellyCount: clearedJelly,
    );

    final stars = calculateStars(newScore);
    final remaining = _state.tiles.where((t) => !toDestroy.any((d) => d.id == t.id)).toList();

    _state = _state.copyWith(
      tiles: remaining,
      score: newScore,
      goal: _currentGoal,
      highScore: max(newScore, _state.highScore),
      comboCount: _state.comboCount + 1,
      starsEarned: stars,
      jellyTiles: remainingJelly,
    );
    notifyListeners();
    await Future.delayed(const Duration(milliseconds: 300));

    final cascaded = _cascadeBoard(_state.tiles);
    _state = _state.copyWith(tiles: cascaded);
    notifyListeners();
    await Future.delayed(const Duration(milliseconds: 350));

    await _processMatchesAndCascade();
  }

  Future<void> _processMatchesAndCascade() async {
    bool isFirstScan = true;
    while (true) {
      final scanResult = _scanAndGenerateSpecials(_state.tiles, isFirstScan ? _lastSwappedTileIds : const {});
      isFirstScan = false;
      final rawMatches = scanResult.matched;
      if (rawMatches.isEmpty) break;

      final exploded = _resolveExplosions(rawMatches, _state.tiles);
      final explodedIds = exploded.map((e) => e.id).toSet();

      final updatedTiles = _state.tiles.map((tile) {
        if (scanResult.specials.containsKey(tile.id)) {
          final type = scanResult.specials[tile.id]!;
          return tile.copyWith(
            type: type,
            emoji: type == TileType.colorBomb ? progressRepository.cachedProgress.colorBombEmoji : tile.emoji,
          );
        }
        return tile;
      }).toList();

      final keptSpecialIds = scanResult.specials.keys.toSet();
      final finalExplodedIds = explodedIds.difference(keptSpecialIds);

      final scoreIncrease = finalExplodedIds.length * 50;
      final newScore = _state.score + scoreIncrease;

      final destroyedTiles = _state.tiles.where((t) => finalExplodedIds.contains(t.id)).toList();
      final remainingJelly = Set<String>.from(_state.jellyTiles);
      int clearedJelly = 0;
      for (final t in exploded) {
        final key = '${t.row}_${t.col}';
        if (remainingJelly.remove(key)) {
          clearedJelly++;
        }
      }

      final postDamageTiles = updatedTiles.map((tile) {
        if (finalExplodedIds.contains(tile.id)) return tile;
        final isAdjacent = destroyedTiles.any((d) =>
            (d.row == tile.row && (d.col - tile.col).abs() == 1) ||
            (d.col == tile.col && (d.row - tile.row).abs() == 1));

        if (isAdjacent) {
          if (tile.isFrozen) {
            return tile.copyWith(isFrozen: false);
          } else if (tile.type == TileType.crate) {
            final nextHp = tile.crateHealth - 1;
            if (nextHp <= 0) {
              return tile.copyWith(
                type: TileType.normal,
                crateHealth: 0,
                emoji: _getAvailableFruits(4)[_random.nextInt(4)],
              );
            } else {
              return tile.copyWith(crateHealth: nextHp);
            }
          }
        }
        return tile;
      }).toList();

      _updateGoalProgress(
        scoreAdded: scoreIncrease,
        clearedTiles: destroyedTiles,
        specialsCreatedCount: scanResult.specials.length,
        isCombo: _state.comboCount > 0,
        clearedJellyCount: clearedJelly,
      );

      final stars = calculateStars(newScore);
      final remaining = postDamageTiles.where((t) => !finalExplodedIds.contains(t.id)).toList();

      _state = _state.copyWith(
        tiles: remaining,
        score: newScore,
        goal: _currentGoal,
        highScore: max(newScore, _state.highScore),
        comboCount: _state.comboCount + 1,
        starsEarned: stars,
        jellyTiles: remainingJelly,
      );
      notifyListeners();
      await Future.delayed(const Duration(milliseconds: 300));

      final cascadedTiles = _cascadeBoard(_state.tiles);
      _state = _state.copyWith(tiles: cascadedTiles);
      notifyListeners();
      await Future.delayed(const Duration(milliseconds: 350));
    }

    final isGoalCompleted = _currentGoal.isCompleted;
    if (!_isZenMode && !_isTwistMode && !_levelConfig.isTimed && isGoalCompleted && _state.movesLeft > 0) {
      await _triggerSugarCrush();
    } else if (!_isZenMode && !_isTwistMode && ((_levelConfig.isTimed ? _state.timeLeft <= 0 : _state.movesLeft <= 0) || isGoalCompleted)) {
      _timeAttackTimer?.cancel();
      final finalStars = isGoalCompleted ? calculateStars(_state.score) : 0;
      _state = _state.copyWith(
        isGameOver: true,
        starsEarned: finalStars,
      );
      if (isGoalCompleted) {
        await progressRepository.completeLevel(
          _state.levelNumber,
          finalStars,
        );
      }
      notifyListeners();
    } else {
      await _checkAndPerformShuffleIfNeeded();
    }
  }

  Future<void> _triggerSugarCrush() async {
    _state = _state.copyWith(isSugarCrush: true);
    notifyListeners();
    await Future.delayed(const Duration(milliseconds: 1000));

    final createdSpecialIds = <String>[];

    while (_state.movesLeft > 0) {
      final candidates = _state.tiles.where((t) => t.type == TileType.normal && !t.isFrozen && !createdSpecialIds.contains(t.id)).toList();
      if (candidates.isEmpty) break;

      final target = candidates[_random.nextInt(candidates.length)];
      final rand = _random.nextInt(3);
      final specialType = rand == 0
          ? TileType.stripedHorizontal
          : (rand == 1 ? TileType.stripedVertical : TileType.wrapped);

      createdSpecialIds.add(target.id);

      final transformedTiles = _state.tiles.map((t) {
        if (t.id == target.id) {
          return t.copyWith(type: specialType);
        }
        return t;
      }).toList();

      final newScore = _state.score + 500;
      final newStars = calculateStars(newScore);

      _state = _state.copyWith(
        movesLeft: _state.movesLeft - 1,
        tiles: transformedTiles,
        score: newScore,
        starsEarned: newStars,
      );
      notifyListeners();
      await Future.delayed(const Duration(milliseconds: 280));
    }

    await Future.delayed(const Duration(milliseconds: 400));

    for (final specialId in createdSpecialIds) {
      final tile = _state.tiles.where((t) => t.id == specialId).firstOrNull;
      if (tile == null || tile.type == TileType.normal) continue;

      final exploded = _resolveExplosions([tile], _state.tiles);
      final explodedIds = exploded.map((e) => e.id).toSet();

      final destroyedTiles = _state.tiles.where((t) => explodedIds.contains(t.id)).toList();
      final remainingJelly = Set<String>.from(_state.jellyTiles);
      for (final t in destroyedTiles) {
        remainingJelly.remove('${t.row}_${t.col}');
      }

      final scoreGain = explodedIds.length * 80;
      final updatedScore = _state.score + scoreGain;
      final remaining = _state.tiles.where((t) => !explodedIds.contains(t.id)).toList();

      _state = _state.copyWith(
        tiles: remaining,
        score: updatedScore,
        starsEarned: calculateStars(updatedScore),
        jellyTiles: remainingJelly,
        comboCount: _state.comboCount + 1,
      );
      notifyListeners();
      await Future.delayed(const Duration(milliseconds: 320));

      final cascadedTiles = _cascadeBoard(_state.tiles);
      _state = _state.copyWith(tiles: cascadedTiles);
      notifyListeners();
      await Future.delayed(const Duration(milliseconds: 380));
    }

    await _processMatchesAndCascade();

    final finalStars = calculateStars(_state.score);
    _state = _state.copyWith(
      isGameOver: true,
      isSugarCrush: false,
      starsEarned: finalStars,
    );
    await progressRepository.completeLevel(
      _state.levelNumber,
      finalStars,
    );
    notifyListeners();
  }

  Future<void> _checkAndPerformShuffleIfNeeded() async {
    if (_state.isGameOver) return;
    final move = _isTwistMode
        ? findPossibleTwistMove(_state.tiles, _state.rows, _state.cols)
        : findPossibleMove(_state.tiles, _state.rows, _state.cols);
    if (move != null) return;

    _state = _state.copyWith(isShuffling: true);
    notifyListeners();
    await Future.delayed(const Duration(milliseconds: 800));

    final nonSpecials = _state.tiles.where((t) => t.type == TileType.normal).toList();
    final emojis = nonSpecials.map((t) => t.emoji).toList();

    int attempts = 0;
    while (attempts < 50) {
      attempts++;
      emojis.shuffle(_random);
      int idx = 0;
      final candidateTiles = _state.tiles.map((t) {
        if (t.type == TileType.normal) {
          final res = t.copyWith(emoji: emojis[idx]);
          idx++;
          return res;
        }
        return t;
      }).toList();

      final existingMatches = _findMatches(candidateTiles);
      if (existingMatches.isEmpty) {
        final possibleMove = _isTwistMode
            ? findPossibleTwistMove(candidateTiles, _state.rows, _state.cols)
            : findPossibleMove(candidateTiles, _state.rows, _state.cols);
        if (possibleMove != null) {
          _state = _state.copyWith(tiles: candidateTiles, isShuffling: false);
          notifyListeners();
          return;
        }
      }
    }

    final freshTiles = _generateInitialBoard(_state.rows, _state.cols, _levelConfig.fruitVarietyCount);
    _state = _state.copyWith(tiles: freshTiles, isShuffling: false);
    notifyListeners();
  }

  ScanResult _scanAndGenerateSpecials(List<TileModel> tiles, [Set<String> prioritizedTileIds = const {}]) {
    final matched = <TileModel>{};
    final specials = <String, TileType>{};
    final horizMatches = <Set<String>>[];
    final vertMatches = <Set<String>>[];

    for (int r = 0; r < _state.rows; r++) {
      int matchStart = 0;
      for (int c = 1; c <= _state.cols; c++) {
        final current = c < _state.cols ? tiles.firstWhere((t) => t.row == r && t.col == c) : null;
        final startTile = tiles.firstWhere((t) => t.row == r && t.col == matchStart);

        if (current != null && current.emoji == startTile.emoji && current.type != TileType.colorBomb) {
          continue;
        } else {
          final length = c - matchStart;
          if (length >= 3) {
            final group = <String>{};
            final lineTiles = <TileModel>[];
            for (int i = matchStart; i < c; i++) {
              final t = tiles.firstWhere((item) => item.row == r && item.col == i);
              matched.add(t);
              group.add(t.id);
              lineTiles.add(t);
            }
            horizMatches.add(group);
            if (length == 4) {
              final specialTile = lineTiles.firstWhere(
                (t) => prioritizedTileIds.contains(t.id),
                orElse: () => lineTiles[1],
              );
              specials[specialTile.id] = TileType.stripedHorizontal;
            } else if (length >= 5) {
              final specialTile = lineTiles.firstWhere(
                (t) => prioritizedTileIds.contains(t.id),
                orElse: () => lineTiles[2],
              );
              specials[specialTile.id] = TileType.colorBomb;
            }
          }
          matchStart = c;
        }
      }
    }

    for (int c = 0; c < _state.cols; c++) {
      int matchStart = 0;
      for (int r = 1; r <= _state.rows; r++) {
        final current = r < _state.rows ? tiles.firstWhere((t) => t.row == r && t.col == c) : null;
        final startTile = tiles.firstWhere((t) => t.row == matchStart && t.col == c);

        if (current != null && current.emoji == startTile.emoji && current.type != TileType.colorBomb) {
          continue;
        } else {
          final length = r - matchStart;
          if (length >= 3) {
            final group = <String>{};
            final lineTiles = <TileModel>[];
            for (int i = matchStart; i < r; i++) {
              final t = tiles.firstWhere((item) => item.row == i && item.col == c);
              matched.add(t);
              group.add(t.id);
              lineTiles.add(t);
            }
            vertMatches.add(group);
            if (length == 4) {
              final specialTile = lineTiles.firstWhere(
                (t) => prioritizedTileIds.contains(t.id),
                orElse: () => lineTiles[1],
              );
              specials[specialTile.id] = TileType.stripedVertical;
            } else if (length >= 5) {
              final specialTile = lineTiles.firstWhere(
                (t) => prioritizedTileIds.contains(t.id),
                orElse: () => lineTiles[2],
              );
              specials[specialTile.id] = TileType.colorBomb;
            }
          }
          matchStart = r;
        }
      }
    }

    for (final hGroup in horizMatches) {
      for (final vGroup in vertMatches) {
        final intersection = hGroup.intersection(vGroup);
        if (intersection.isNotEmpty) {
          final intersectId = intersection.first;
          if (specials[intersectId] != TileType.colorBomb) {
            specials[intersectId] = TileType.wrapped;
          }
        }
      }
    }

    return ScanResult(matched: matched.toList(), specials: specials);
  }

  List<TileModel> _resolveExplosions(List<TileModel> initialMatches, List<TileModel> allTiles) {
    final exploded = <TileModel>{...initialMatches};
    final queue = List<TileModel>.from(initialMatches);

    while (queue.isNotEmpty) {
      final current = queue.removeLast();
      if (current.type == TileType.stripedHorizontal) {
        final rowTiles = allTiles.where((t) => t.row == current.row && !exploded.contains(t));
        for (final t in rowTiles) {
          exploded.add(t);
          queue.add(t);
        }
      } else if (current.type == TileType.stripedVertical) {
        final colTiles = allTiles.where((t) => t.col == current.col && !exploded.contains(t));
        for (final t in colTiles) {
          exploded.add(t);
          queue.add(t);
        }
      } else if (current.type == TileType.wrapped) {
        final blastRadius = allTiles.where((t) =>
            (t.row - current.row).abs() <= 1 &&
            (t.col - current.col).abs() <= 1 &&
            !exploded.contains(t));
        for (final t in blastRadius) {
          exploded.add(t);
          queue.add(t);
        }
      }
    }
    return exploded.toList();
  }

  List<TileModel> _cascadeBoard(List<TileModel> remainingTiles) {
    final newTiles = <TileModel>[];
    final availableFruits = _getAvailableFruits(_levelConfig.fruitVarietyCount);

    for (int c = 0; c < _state.cols; c++) {
      final colTiles = remainingTiles.where((t) => t.col == c).toList()
        ..sort((a, b) => b.row.compareTo(a.row));

      int targetRow = _state.rows - 1;
      for (final tile in colTiles) {
        newTiles.add(tile.copyWith(row: targetRow));
        targetRow--;
      }

      while (targetRow >= 0) {
        final emoji = availableFruits[_random.nextInt(availableFruits.length)];
        newTiles.add(TileModel(
          id: '${DateTime.now().microsecondsSinceEpoch}_${targetRow}_${c}_${_random.nextInt(1000)}',
          row: targetRow,
          col: c,
          emoji: emoji,
        ));
        targetRow--;
      }
    }
    return newTiles;
  }

  List<TileModel> _findMatches(List<TileModel> tiles) {
    return _scanAndGenerateSpecials(tiles).matched;
  }
}

class ScanResult {
  final List<TileModel> matched;
  final Map<String, TileType> specials;

  ScanResult({required this.matched, required this.specials});
}
