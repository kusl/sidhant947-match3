import 'package:hive_ce/hive_ce.dart';
import 'package:match3/domain/models/user_progress.dart';

class UserProgressAdapter extends TypeAdapter<UserProgress> {
  @override
  final int typeId = 0;

  @override
  UserProgress read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{};
    for (int i = 0; i < numOfFields; i++) {
      fields[reader.readByte()] = reader.read();
    }

    final rawStars = fields[2];
    final Map<String, int> starsMap;
    if (rawStars is Map) {
      starsMap = Map<String, int>.from(rawStars);
    } else {
      starsMap = const {};
    }

    final rawCustom = fields[7];
    final List<String> customList;
    if (rawCustom is List) {
      customList = List<String>.from(rawCustom);
    } else {
      customList = const ['🍎', '🫐', '🍐', '🍋', '🍇', '🍊', '🍒', '🍉', '🍍', '🍓'];
    }

    return UserProgress(
      currentLevel: fields[0] as int? ?? 1,
      highestLevelCompleted: fields[1] as int? ?? 0,
      levelStars: starsMap,
      hintsEnabled: fields[3] as bool? ?? true,
      hapticsEnabled: fields[4] as bool? ?? true,
      audioEnabled: fields[5] as bool? ?? true,
      emojiPreset: fields[6] as String? ?? 'fruits',
      customEmojis: customList,
      themeId: fields[8] as String? ?? 'dark_charcoal',
      twistLimiterEnabled: fields[9] as bool? ?? false,
      crateEmoji: fields[10] as String? ?? '📦',
      colorBombEmoji: fields[11] as String? ?? '🍭',
      disableTimedChallenges: fields[12] as bool? ?? false,
    );
  }

  @override
  void write(BinaryWriter writer, UserProgress obj) {
    writer.writeByte(13);
    writer.writeByte(0);
    writer.write(obj.currentLevel);
    writer.writeByte(1);
    writer.write(obj.highestLevelCompleted);
    writer.writeByte(2);
    writer.write(obj.levelStars);
    writer.writeByte(3);
    writer.write(obj.hintsEnabled);
    writer.writeByte(4);
    writer.write(obj.hapticsEnabled);
    writer.writeByte(5);
    writer.write(obj.audioEnabled);
    writer.writeByte(6);
    writer.write(obj.emojiPreset);
    writer.writeByte(7);
    writer.write(obj.customEmojis);
    writer.writeByte(8);
    writer.write(obj.themeId);
    writer.writeByte(9);
    writer.write(obj.twistLimiterEnabled);
    writer.writeByte(10);
    writer.write(obj.crateEmoji);
    writer.writeByte(11);
    writer.write(obj.colorBombEmoji);
    writer.writeByte(12);
    writer.write(obj.disableTimedChallenges);
  }
}
